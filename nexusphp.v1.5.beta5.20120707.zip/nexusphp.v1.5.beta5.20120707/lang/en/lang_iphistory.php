<?php

$lang_iphistory = array
(
	'std_error' => "Error",
	'std_invalid_id' => "Invalid ID",
	'text_user_not_found' => "User not found",
	'head_ip_history_log_for' => "IP History Log for ",
	'text_historical_ip_by' => "Historical IP addresses used by ",
	'col_last_access' => "Last access",
	'col_ip' => "IP",
	'col_hostname' => "Hostname",
	'text_not_available' => "N/A",
	'text_duplicate' => "Dupe",
);
?>

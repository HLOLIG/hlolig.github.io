<?php

$lang_adredir = array
(
	'std_error' => "Error",
	'std_ad_system_disabled' => "Ad system disabled.",
	'std_invalid_ad_id' => "Invalid ad id",
	'std_no_redirect_url' => "No redirect URL."
);

?>

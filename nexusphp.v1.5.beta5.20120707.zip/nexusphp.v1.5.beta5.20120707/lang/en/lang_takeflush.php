<?php

$lang_takeflush = array
(
	'std_failed' => "Failed",
	'std_success' => "Success",
	'std_ghost_torrents_cleaned' => "ghost torrents were sucessfully cleaned.",
	'std_cannot_flush_others' => "You can only clean your own ghost torrents"
);

?>
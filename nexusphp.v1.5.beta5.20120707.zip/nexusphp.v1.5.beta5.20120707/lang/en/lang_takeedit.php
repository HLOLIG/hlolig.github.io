<?php

$lang_takeedit = array
(
	'std_edit_failed' => "Edit failed!",
	'std_missing_form_data' => "missing form data",
	'std_not_owner' => "You're not the owner! How did that happen?",
	'std_nfo_too_big' => "NFO is too big! Max 65,535 bytes.",
	'std_cannot_move_torrent' => "You have no permission to move torrents to another section. BTW, how do you get here?"
);

?>
<?php

$lang_takecontact = array
(
	'std_error' => "Error",
	'std_method' => "Method",
	'std_please_enter_something' => "Please enter something!",
	'std_please_define_subject' => "You need to define subject!",
	'std_message_flooding' => "Message Flooding Not Allowed. Please wait ",
	'std_second' => " second",
	'std_s' => "s",
	'std_before_sending_pm' => " before sending PM to STAFF.",
	'std_succeeded' => "Succeeded",
	'std_message_succesfully_sent' => "Message was succesfully sent!"
);

?>
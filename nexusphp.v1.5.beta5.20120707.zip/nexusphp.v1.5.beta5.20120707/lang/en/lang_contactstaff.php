<?php

$lang_contactstaff = array
(
	'head_contact_staff' => "Contact Staff",
	'text_message_to_staff' => "Send message to Staff",
	'row_subject' => "Subject",
	'row_body' => "Body",
	'submit_send_it' => "Send&nbsp;It!"
);

?>
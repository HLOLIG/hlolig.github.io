<?php

$lang_polloverview = array
(
	'std_error' => "錯誤",
	'head_poll_overview' => "投票概況",
	'text_polls_overview' => "投票概況",
	'col_id' => "ID",
	'col_added' => "添加時間",
	'col_question' => "問題",
	'text_no_users_voted' => "對不起...還沒有用戶投過票！",
	'text_no_poll_id' => "對不起...沒有該ID的投票！",
	'text_poll_question' => "投票問題",
	'col_option_no' => "編號",
	'col_options' => "選項",
	'text_polls_user_overview' => "投票用戶情況",
	'col_username' => "用戶名",
	'col_selection' => "選項",
);

?>

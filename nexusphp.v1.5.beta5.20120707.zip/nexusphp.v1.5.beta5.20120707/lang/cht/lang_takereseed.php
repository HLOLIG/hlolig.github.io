<?php

$lang_takereseed = array
(
	'head_reseed_request' => "續種請求！",
	'std_it_worked' => "成功了！完成下載的用戶將收到請求續種的短訊。",
	'std_error' => "錯誤",
	'std_torrent_not_dead' => "該種子沒有斷種。",
	'std_reseed_sent_recently' => "該種子在過去15分鐘內已收到一次續種請求。請耐心等待好心人續種。",
);

?>

<?php

$lang_forummanage = array
(
	'head_forum_management' => "論壇管理",
	'text_forum_management' => "論壇管理",
	'text_edit_forum' => "編輯論壇版塊",
	'row_forum_name' => "版塊名字",
	'row_forum_description' => "版塊描述",
	'row_overforum' => "論壇分區",
	'row_moderator' => "版主",
	'text_moderator_note' => "最多3個版主。用','分割用戶名",
	'row_minimum_read_permission' => "最低允許閱讀等級",
	'row_minimum_write_permission' => "最低允許回復等級",
	'row_minimum_create_topic_permission' => "最低允許發布主題等級",
	'row_forum_order' => "論壇版塊排序",
	'text_forum_order_note' => "按數字升序排列，即0顯示在最頂端。",
	'submit_edit_forum' => "編輯論壇版塊",
	'text_no_records_found' => "對不起，沒有記錄！",
	'text_add_forum' => "添加論壇版塊",
	'text_make_new_forum' => "添加新的版塊",
	'submit_overforum_management' => "論壇分區管理",
	'submit_add_forum' => "添加版塊",
	'col_name' => "名字",
	'col_overforum' => "論壇分區",
	'col_read' => "讀",
	'col_write' => "回復",
	'col_create_topic' => "創建主題",
	'col_moderator' => "版主",
	'col_modify' => "修改",
	'text_not_available' => "暫無",
	'text_edit' => "編輯",
	'text_delete' => "刪除",
	'js_sure_to_delete_forum' => "你確定要刪除此論壇版塊嗎？",
	'submit_make_forum' => "創建論壇版塊"
);

?>

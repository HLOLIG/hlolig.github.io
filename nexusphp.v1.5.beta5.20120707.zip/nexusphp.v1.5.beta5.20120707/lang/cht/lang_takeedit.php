<?php

$lang_takeedit = array
(
	'std_edit_failed' => "編輯失敗！",
	'std_missing_form_data' => "有項目沒有填寫",
	'std_not_owner' => "你不是發種者！怎麼回事？\n",
	'std_nfo_too_big' => "NFO過大！最大為65,535位元組。",
	'std_cannot_move_torrent' => "你沒有將種子移至另一區的許可權。另外，你怎麼會到這？"
);

?>
<?php

$lang_moforums = array
(
	'head_overforum_management' => "論壇分區管理",
	'text_forum_management' => "論壇管理",
	'text_overforum_management' => "論壇分區管理",
	'col_name' => "名字",
	'col_viewed_by' => "最低允許查看等級",
	'col_modify' => "修改",
	'text_edit' => "編輯",
	'text_delete' => "刪除",
	'js_sure_to_delete_overforum' => "你確定要刪除此論壇分區嗎？",
	'text_no_records_found' => "對不起，沒有記錄！",
	'text_new_overforum' => "新論壇分區",
	'text_overforum_name' => "名字",
	'text_overforum_description' => "描述",
	'text_minimum_view_permission' => "最低允許閱讀等級",
	'text_overforum_order' => "論壇分區排序",
	'text_overforum_order_note' => "按數字升序排列，即0顯示在最頂端。",
	'submit_make_overforum' => "創建新的分區",
	'text_edit_overforum' => "編輯分區",
	'submit_edit_overforum' => "編輯分區"
);

?>

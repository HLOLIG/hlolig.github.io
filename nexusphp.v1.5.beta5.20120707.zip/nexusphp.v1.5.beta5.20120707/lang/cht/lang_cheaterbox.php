<?php

$lang_cheaterbox = array
(
	'std_oho' => "噢哦！",
	'std_no_suspect_detected' => "還沒有檢測到任何作弊嫌疑者。",
	'head_cheaterbox' => "作弊者",
	'text_cheaterbox' => "作弊者 <font class=striking>BETA</font>",
	'col_added' => "時間",
	'col_suspect' => "嫌疑者",
	'col_hit' => "次數",
	'col_torrent' => "種子",
	'col_ul' => "上傳",
	'col_dl' => "下載",
	'col_ann_time' => "匯報時間",
	'col_seeders' => "做種者",
	'col_leechers' => "下載者",
	'col_comment' => "備注",
	'col_dealt_with' => "處理",
	'col_action' => "行為",
	'text_torrent_does_not_exist' => "種子不存在或已被刪除",
	'text_yes' => "是",
	'text_no' => "否",
	'submit_set_dealt' => "設為已處理",
	'submit_delete' => "刪除"
);

?>

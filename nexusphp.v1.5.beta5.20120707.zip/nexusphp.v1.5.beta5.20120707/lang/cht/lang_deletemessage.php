<?php

$lang_deletemessage = array
(
	'std_bad_message_id' => "錯誤短訊ID",
	'std_not_suggested' => "如果我是你，我不會這麼做...",
	'std_not_in_inbox' => "你的收件箱中沒有該短訊。",
	'std_not_in_sentbox' => "你的發件箱中沒有該短訊。",
	'std_unknown_pm_type' => "未知短訊類型。"
);

?>
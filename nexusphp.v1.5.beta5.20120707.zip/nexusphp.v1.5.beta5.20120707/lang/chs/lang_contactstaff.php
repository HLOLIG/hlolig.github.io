<?php

$lang_contactstaff = array
(
	'head_contact_staff' => "联系管理组",
	'text_message_to_staff' => "给管理组发短讯",
	'row_subject' => "标题",
	'row_body' => "正文",
	'submit_send_it' => "发送",
);

?>

<?php

$lang_takeinvite = array
(
	'head_invitation_failed' => "邀请失败！",
	'std_must_enter_email' => "你必须输入邮箱地址！",
	'std_invalid_email_address' => "无效的邮箱地址！",
	'std_must_enter_personal_message' => "请添加信件中的私人内容。",
	'std_email_address' => "邮箱地址",
	'std_is_in_use' => "已经在使用。",
	'mail_here' => "这里",
	'mail_tilte' => "网站邀请函",
	'mail_one' => "你好，<br /><br />用户",
	'mail_two' => "邀请你加入".$SITENAME."社区。
".$SITENAME."拥有知识丰富的用户。 <br />如果你有意加入，请在阅读网站规则后确认该邀请。<br /><br />请点击以下链接确认邀请：",
	'mail_three' => "请在",
	'mail_four' => "天内确认该邀请，之后邀请将作废。<br />".$SITENAME."真诚欢迎你加入我们的社区！<br /><br />来自邀请者",
	'mail_five' => "的话：",
	'mail_six' => "如果你根本不认识邀请者，请将此邮件转发至".$REPORTMAIL."<br /><br />------<br />".$SITENAME."网站",
	'std_error' => "错误",
	'std_invite_denied' => "你的用户等级不允许发送邀请。你怎么到这来的？",
	'std_email_address_banned' => "邮箱地址被禁用！",
	'std_wrong_email_address_domains' => "不允许发送邀请给此邮箱地址！请使用以下邮箱：",
	'std_no_invite' => "你没有剩余邀请名额。你怎么到这来的？",
	'std_invitation_already_sent_to' => "发送失败！此邮箱",
	'std_await_user_registeration' => "已收到过邀请函，请勿重复发送。请等待用户注册。",
);

?>

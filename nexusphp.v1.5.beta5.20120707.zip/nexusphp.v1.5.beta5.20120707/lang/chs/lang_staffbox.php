<?php

$lang_staffbox = array
(
	'head_staff_pm' => "管理组信箱",
	'text_staff_pm' => "管理组信箱",
	'std_sorry' => "对不起",
	'std_no_messages_yet' => "暂时没有短讯！",
	'col_subject' => "主题",
	'col_sender' => "发讯者",
	'col_added' => "时间",
	'col_answered' => "回复",
	'col_action' => "行为",
	'text_yes' => "是",
	'text_no' => "否",
	'submit_set_answered' => "设为已回复",
	'submit_delete' => "删除",
	'text_system' => "系统",
	'head_view_staff_pm' => "查看管理组信箱",
	'col_from' => "自",
	'col_date' => "日期",
	'col_answered_by' => "回复者",
	'text_reply' => "回复",
	'text_mark_answered' => "设为已回复",
	'text_delete' => "删除",
	'std_error' => "错误",
	'std_no_user_id' => "没有此ID的用户。",
	'head_answer_to_staff_pm' => "回复管理组信息",
	'text_answering_to' => "回复",
	'text_sent_by' => " - 来自",
	'std_body_is_empty' => "回复不能为空白！",
);

?>

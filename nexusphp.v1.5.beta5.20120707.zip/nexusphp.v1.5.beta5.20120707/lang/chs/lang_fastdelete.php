<?php

$lang_fastdelete = array
(
	'std_delete_failed' => "删除失败！",
	'std_missing_form_data' => "有项目没填",
	'text_no_permission' => "你没有权限删除该种子，只有版主及以上用户才可以。如果你想删除自己发布的种子，请联系他们。\n",
	'std_delete_torrent' => "删除种子",
	'std_delete_torrent_note' => "确认：你即将删除种子，点击",
	'std_here_if_sure' => "这里</a>来确认。"
);

?>

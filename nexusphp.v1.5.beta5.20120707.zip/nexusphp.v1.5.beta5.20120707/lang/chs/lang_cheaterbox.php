<?php

$lang_cheaterbox = array
(
	'std_oho' => "噢哦！",
	'std_no_suspect_detected' => "还没有检测到任何作弊嫌疑者。",
	'head_cheaterbox' => "作弊者",
	'text_cheaterbox' => "作弊者 <font class=striking>BETA</font>",
	'col_added' => "时间",
	'col_suspect' => "嫌疑者",
	'col_hit' => "次数",
	'col_torrent' => "种子",
	'col_ul' => "上传",
	'col_dl' => "下载",
	'col_ann_time' => "汇报时间",
	'col_seeders' => "做种者",
	'col_leechers' => "下载者",
	'col_comment' => "备注",
	'col_dealt_with' => "处理",
	'col_action' => "行为",
	'text_torrent_does_not_exist' => "种子不存在或已被删除",
	'text_yes' => "是",
	'text_no' => "否",
	'submit_set_dealt' => "设为已处理",
	'submit_delete' => "删除"
);

?>

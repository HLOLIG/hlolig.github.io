<?php

$lang_userhistory = array
(
	'std_error' => "错误",
	'std_permission_denied' => "你没有该权限",
	'std_no_posts_found' => "没有找到该帖子",
	'head_posts_history' => "帖子历史",
	'text_posts_history_for' => "用户帖子历史-",
	'text_forum' => "<b>论坛:&nbsp;</b>",
	'text_topic' => "<b>主题:&nbsp;</b>",
	'text_post' => "<b>帖子:&nbsp;</b>",
	'text_new' => "新！",
	'text_last_edited' => "最后被",
	'text_at' => "编辑于",
	'std_no_comments_found' => "没有找到评论",
	'head_comments_history' => "评论历史",
	'text_comments_history_for' => "用户评论历史-",
	'text_torrent' => "<b>种子:&nbsp;</b>",
	'text_comment' => "<b>评论:&nbsp;",
	'std_history_error' => "错误",
	'std_unkown_action' => "未知行为",
	'std_invalid_or_no_query' => "无效或没有该项。"
);

?>

<?php

$lang_polloverview = array
(
	'std_error' => "错误",
	'head_poll_overview' => "投票概况",
	'text_polls_overview' => "投票概况",
	'col_id' => "ID",
	'col_added' => "添加时间",
	'col_question' => "问题",
	'text_no_users_voted' => "对不起...还没有用户投过票！",
	'text_no_poll_id' => "对不起...没有该ID的投票！",
	'text_poll_question' => "投票问题",
	'col_option_no' => "编号",
	'col_options' => "选项",
	'text_polls_user_overview' => "投票用户情况",
	'col_username' => "用户名",
	'col_selection' => "选项",
);

?>

<?php

$lang_faq = array
(
	'head_faq' => "常见问题",
	'text_welcome_to' => "欢迎来到",
	'text_welcome_content_one' => "我们的目标是提供纯粹高品质的东西。因此，只有授权的用户才能发布种子。如果你有0-day资源的来源，请不要迟疑<a class=\"faqlink\" href=\"contactstaff.php\">联系</a>我们！<br /><br />这是非公开BT站点，你必须注册后才能访问。",
	'text_welcome_content_two' => "在".$SITENAME."干任何事前，我们建议你先阅读站点的<a class=\"faqlink\" href=\"rules.php\">规则</a>！规则只有简单几条，但我们要求用户严格遵照。<br /><br />在使用前，请阅读".$SITENAME."<a class=\"faqlink\" href=\"useragreement.php\">用户协定</a>。",
	'text_contents' => "目录",
);

?>
